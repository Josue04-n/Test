<?php

include_once "cruds.php";
$opcion = $_SERVER['REQUEST_METHOD'];

switch ($opcion) {
    case 'GET':
        cruds::ListaProductos();
        break;
    case 'POST':
        cruds::RegistrarVenta();
        break;
}



?>