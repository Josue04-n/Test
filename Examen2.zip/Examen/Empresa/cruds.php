<?php
    include_once "conexion.php";

    class Cruds {

        // LISTAR CLIENTES
        public static function ListarClientes() {
            $ObjConexion = new Conexion();
            $conectar = $ObjConexion->conectar();
            $sql = "SELECT * FROM clientes";
            $resultado = $conectar->prepare($sql);
            $resultado->execute();
            $data = $resultado->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($data);
        }

        // LISTAR PRODUCTOS
        public static function ListarProductos() {
            $ObjConexion = new Conexion();
            $conectar = $ObjConexion->conectar();
            $sql = "SELECT * FROM productos";
            $resultado = $conectar->prepare($sql);
            $resultado->execute();
            $data = $resultado->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($data);
        }

        // BUSCAR CLIENTE POR CEDULA
        public static function BuscarCliente() {
            $ObjConexion = new Conexion();
            $conectar = $ObjConexion->conectar();
            $cedula = $_GET['cedula'];
            $sql = "SELECT * FROM clientes WHERE cedula = '$cedula'";
            $resultado = $conectar->prepare($sql);
            $resultado->execute();
            $data = $resultado->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($data);
        }

        // REGISTRAR PEDIDO
        public static function RegistrarPedido() {
            $ObjConexion = new Conexion();
            $conectar = $ObjConexion->conectar();

            $datos = json_decode(file_get_contents("php://input"), true);

            $cedula    = trim($datos['cedula'] ?? "");
            $producto  = (int)($datos['producto'] ?? 0);
            $cantidad  = (int)($datos['cantidad'] ?? 0);

            if ($cedula === "" || $producto <= 0 || $cantidad <= 0) {
                $data = array("error" => true, "mensaje" => "Todos los campos son requeridos");
                echo json_encode($data);
                return;
            }

            try {
                // Transaccion para evitar vender stock por encima del disponible.
                $conectar->beginTransaction();

                $sqlCliente = "SELECT cedula FROM clientes WHERE cedula = ?";
                $resCliente = $conectar->prepare($sqlCliente);
                $resCliente->execute([$cedula]);
                $cliente = $resCliente->fetch(PDO::FETCH_ASSOC);

                if (!$cliente) {
                    $conectar->rollBack();
                    echo json_encode(array("error" => true, "mensaje" => "Cliente no encontrado"));
                    return;
                }

                $sqlProducto = "SELECT precio, stock FROM productos WHERE id = ? FOR UPDATE";
                $resProducto = $conectar->prepare($sqlProducto);
                $resProducto->execute([$producto]);
                $prod = $resProducto->fetch(PDO::FETCH_ASSOC);

                if (!$prod) {
                    $conectar->rollBack();
                    echo json_encode(array("error" => true, "mensaje" => "Producto no encontrado"));
                    return;
                }

                $stockActual = (int)$prod['stock'];

                if ($cantidad > $stockActual) {
                    $conectar->rollBack();
                    echo json_encode(array(
                        "error" => true,
                        "mensaje" => "Stock insuficiente. Disponible: " . $stockActual
                    ));
                    return;
                }

                $total = (float)$prod['precio'] * $cantidad;
                $nuevoStock = $stockActual - $cantidad;

                $sqlInsert = "INSERT INTO pedidos (cedula, producto_id, cantidad, total) VALUES (?, ?, ?, ?)";
                $resultado = $conectar->prepare($sqlInsert);
                $resultado->execute([$cedula, $producto, $cantidad, $total]);

                $sqlStock = "UPDATE productos SET stock = ? WHERE id = ?";
                $resStock = $conectar->prepare($sqlStock);
                $resStock->execute([$nuevoStock, $producto]);

                $conectar->commit();

                $data = array(
                    "error" => false,
                    "mensaje" => "Pedido registrado correctamente",
                    "total" => $total,
                    "stock_restante" => $nuevoStock
                );
                echo json_encode($data);
            } catch (Exception $ex) {
                if ($conectar->inTransaction()) {
                    $conectar->rollBack();
                }
                echo json_encode(array("error" => true, "mensaje" => "No se pudo registrar el pedido"));
            }
        }

        // PEDIDOS POR CLIENTE
        public static function PedidosPorCliente() {
            $ObjConexion = new Conexion();
            $conectar = $ObjConexion->conectar();
            $cedula = $_GET['cedula'];

            $sql = "SELECT pedidos.id, productos.nombre, pedidos.cantidad, pedidos.total 
                    FROM pedidos 
                    JOIN productos ON pedidos.producto_id = productos.id 
                    WHERE pedidos.cedula = '$cedula'";
            $resultado = $conectar->prepare($sql);
            $resultado->execute();
            $data = $resultado->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($data);
        }
    }
?>