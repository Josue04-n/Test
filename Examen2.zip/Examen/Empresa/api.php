<?php
    include_once "cruds.php";

    header("Content-Type: application/json; charset=UTF-8");

    $metodo = $_SERVER['REQUEST_METHOD'];

    switch ($metodo) {
        case 'GET':
            if (isset($_GET['productos'])) {
                Cruds::ListarProductos();
            } else if (isset($_GET['pedidos'])) {
                Cruds::PedidosPorCliente();
            } else if (isset($_GET['cedula'])) {
                Cruds::BuscarCliente();
            } else {
                Cruds::ListarClientes();
            }
            break;

        case 'POST':
            Cruds::RegistrarPedido();
            break;

        default:
            echo json_encode("Metodo no permitido");
            break;
    }
?>