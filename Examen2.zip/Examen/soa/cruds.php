<?php
    include_once "conexion.php";

    class Cruds {


        public static function SelectEST()  {
            
            $ObjConexion = new Conexion();
            $conectar = $ObjConexion->conectar();
            $sqlSelect = "select * from estudiantes ";
            $resultado = $conectar->prepare($sqlSelect);
            $resultado->execute();
            $data = $resultado->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode($data);
        
        
        }

        public static function InsertEST()  {
            $ObjConexion = new Conexion();
            $conectar = $ObjConexion->conectar();
            $cedula = $_POST['txtcedula'];
            $nombre = $_POST['txtnombre'];
            $apellido = $_POST['txtapellido'];
            $telefono = $_POST['txttelefono'];
            $direccion = $_POST['txtdireccion'];
            
            if (empty($cedula) || empty($nombre) || empty($apellido) || empty($telefono) || empty($direccion)) {
                $data = array("error" => true, "mensaje" => "Todos los campos son requeridos");
                echo json_encode($data);
                return;
            }
            
            // Verificar si la cédula ya existe
            $sqlVerificar = "select * from estudiantes where cedula = '$cedula'";
            $resultado_verificar = $conectar->prepare($sqlVerificar);
            $resultado_verificar->execute();
            
            if ($resultado_verificar->rowCount() > 0) {
                $data = array("error" => true, "mensaje" => "La cédula ya existe en el sistema");
                echo json_encode($data);
                return;
            }

            $sqlInsert = "insert into estudiantes (cedula, nombre, apellido, telefono, direccion) values ('$cedula','$nombre','$apellido','$telefono','$direccion')";
            $resultado = $conectar->prepare($sqlInsert);
            $resultado->execute();
            $data = array("error" => false, "mensaje" => "Se insertó correctamente el estudiante");
            echo json_encode($data);

        }

        public static function DeleteEST()  {
            $ObjConexion = new Conexion();
            $conectar = $ObjConexion->conectar();
            $cedula = $_GET['txtcedula'];
            $sqlDelete = "delete from estudiantes where cedula ='$cedula'";
            $resultado = $conectar->prepare($sqlDelete);
            $resultado->execute();
            
            if ($resultado->rowCount() > 0) {
                $data = array("error" => false, "mensaje" => "Se eliminó correctamente el estudiante");
            } else {
                $data = array("error" => true, "mensaje" => "No se pudo eliminar el estudiante");
            }
            
            echo json_encode($data);
        }

        public static function UpdateEST()  {
            $ObjConexion = new Conexion();
            $conectar = $ObjConexion->conectar();
            
            // Para PUT, leer datos del body
            parse_str(file_get_contents("php://input"), $data);
            
            $cedula = isset($data['txtcedula']) ? $data['txtcedula'] : '';
            $nombre = isset($data['txtnombre']) ? $data['txtnombre'] : '';
            $apellido = isset($data['txtapellido']) ? $data['txtapellido'] : '';
            $telefono = isset($data['txttelefono']) ? $data['txttelefono'] : '';
            $direccion = isset($data['txtdireccion']) ? $data['txtdireccion'] : '';
            
            // Validar que los campos no estén vacíos
            if (empty($cedula) || empty($nombre) || empty($apellido) || empty($telefono) || empty($direccion)) {
                $data_response = array("error" => true, "mensaje" => "Todos los campos son requeridos");
                echo json_encode($data_response);
                return;
            }
            
            $sqlUpdate = "UPDATE estudiantes SET nombre='$nombre',
                                             apellido='$apellido',
                                             direccion='$direccion',
                                             telefono='$telefono' 
                                             WHERE cedula='$cedula'";
            $resultado = $conectar->prepare($sqlUpdate);
            
            if ($resultado->execute()) {
                $data_response = array("error" => false, "mensaje" => "Se actualizó correctamente el estudiante");
            } else {
                $data_response = array("error" => true, "mensaje" => "No se pudo actualizar el estudiante");
            }
            
            echo json_encode($data_response);
        }

        public static function buscarEST()  {
            $ObjConexion = new Conexion();
            $conectar = $ObjConexion->conectar();
            $cedula = $_GET['txtcedula'];
            $sqlSelect = "select * from estudiantes where cedula ='$cedula'";
            $resultado = $conectar->prepare($sqlSelect);
            $resultado->execute();
            $data = $resultado->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($data);

        }

        

    }

?>