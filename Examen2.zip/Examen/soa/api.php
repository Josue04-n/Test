<?php
    include_once "cruds.php";
    $option = $_SERVER['REQUEST_METHOD'];
    
    switch ($option) {
        case 'GET':
            if (isset($_GET['txtcedula']) && !empty($_GET['txtcedula'])) {
                Cruds::buscarEST();
            } else {
                Cruds::SelectEST();
            }
            break;
        case 'POST':
            Cruds::InsertEST();
            break;
        case 'PUT':
            Cruds::UpdateEST();
            break;
        case 'DELETE':
            Cruds::DeleteEST();
            break;
        default:
            echo json_encode("Metodo no permitido");
            break;
    }

?>