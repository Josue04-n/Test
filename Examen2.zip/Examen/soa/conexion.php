<?php 
    class Conexion {
        
        public function conectar (){
            $server = "localhost";
            $user= "root";
            $password = "";
            $database = "soa";

            try {
                $conn = new PDO("mysql:host=$server;dbname=$database", $user, $password);
                //echo ("Se conecto");
            } catch (Exception $ex) {
                die("Fallo la conexion" . $ex->getMessage());
            }

            return $conn;
        }
    }

?>