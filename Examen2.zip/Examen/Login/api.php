<?php
include_once "cruds.php";

$opcion = $_SERVER['REQUEST_METHOD'];
$accion = isset($_GET['accion']) ? $_GET['accion'] : 'login';

switch ($opcion) {
    case 'POST':
    if ($accion === 'registrar') {
        Cruds::Registrarse();
    } else {
        Cruds::Login();
    }
    break;
}
?>