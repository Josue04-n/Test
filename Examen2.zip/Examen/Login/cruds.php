<?php
require_once "conexion.php";

class Cruds {

    public static function Login() 
        {
        $objConexion = new Conexion;
        $conectar = $objConexion->conectar();
        
        $data = json_decode(file_get_contents("php://input"), true);

        if (!is_array($data) || !isset($data['txtEmail'], $data['txtContrasenia'])) {
            echo json_encode(["error" => "Datos incompletos"]);
            return;
        }
        
        $usuario = $data['txtEmail'];
        $clave = $data['txtContrasenia'];
        
        $sql = "SELECT * FROM usuarios WHERE email = ? AND contrasenia = ?";
        $resultado = $conectar->prepare($sql);
        $resultado->execute([$usuario, $clave]);
        
        $user = $resultado->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            echo json_encode(["mensaje" => "Login correcto"]);
        } else {
            echo json_encode(["error" => "Usuario o clave incorrectos"]);
            }
        }

    public static function Registrarse()
        {
        $objConexion = new Conexion;
        $conectar = $objConexion->conectar();

        $data = json_decode(file_get_contents("php://input"), true);

        if (!is_array($data) || !isset($data['txtEmail'], $data['txtContrasenia'])) {
            echo json_encode(["error" => "Datos incompletos"]);
            return;
        }

        $txtEmail = trim($data['txtEmail']);
        $txtContrasenia = trim($data['txtContrasenia']);

        if ($txtEmail === "" || $txtContrasenia === "") {
            echo json_encode(["error" => "Email y contraseña son obligatorios"]);
            return;
        }

        $sqlExiste = "SELECT email FROM usuarios WHERE email = ? LIMIT 1";
        $resultadoExiste = $conectar->prepare($sqlExiste);
        $resultadoExiste->execute([$txtEmail]);

        if ($resultadoExiste->fetch(PDO::FETCH_ASSOC)) {
            echo json_encode(["error" => "El usuario ya existe"]);
            return;
        }

        $sqlInsert = "INSERT INTO usuarios (email, contrasenia) VALUES (?, ?)";
        $resultadoInsert = $conectar->prepare($sqlInsert);
        $respuesta = $resultadoInsert->execute([$txtEmail, $txtContrasenia]);

        if ($respuesta) {
            echo json_encode(["mensaje" => "Usuario registrado correctamente"]);
        } else {
            echo json_encode(["error" => "No se pudo registrar el usuario"]);
        }
        }
}
?>