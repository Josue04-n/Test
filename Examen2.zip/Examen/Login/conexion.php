<?php 
    class Conexion {
        
        public function conectar (){
            $server = "localhost";
            $user= "root";
            $password = "";
            $database = "usuario";
         
            try {
                $conn = new PDO("mysql:host=$server;dbname=$database", $user, $password);
                //echo ("Se conecto");
            } catch (Exception $ex) {
                //echo ("No se conecto");    
               die("Fallo la conexion" . $ex->getMessage());
            }

            return $conn;
        }
    }

?>