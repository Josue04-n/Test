<?php

include_once "conexion.php";

    class Cruds {

    public static function ListaProductos() {

        $objConexion = new Conexion; // instancia de conexion
        $conectar = $objConexion->conectar();  // Acedemos al metodo Conectar
        $slqSelect = "SELECT * FROM productos"; //Consulta
        $resultado = $conectar->prepare($slqSelect); // mandamos la consulta 
        $resultado->execute();  // obtenermos el resultado
        $data = $resultado->fetchAll(PDO::FETCH_ASSOC); //obtener los registros

        echo json_encode($data); //mandamos en formato Json


    }

    public static function ListaVentas() {

        $objConexion = new Conexion; // instancia de conexion
        $conectar = $objConexion->conectar();  // Acedemos al metodo Conectar
        $slqSelect = "SELECT * FROM ventas"; //Consulta
        $resultado = $conectar->prepare($slqSelect); // mandamos la consulta 
        $resultado->execute();  // obtenermos el resultado
        $data = $resultado->fetchAll(PDO::FETCH_ASSOC); //obtener los registros

        echo json_encode($data); //mandamos en formato Json


    }

    public static function RegistrarVenta()
    {
        $objConexion = new Conexion;
        $conectar = $objConexion->conectar();

        $data = json_decode(file_get_contents("php://input"), true);
        $producto_id = $data['txtProducto'];
        $cantidad = $data['txtCantidad'];
        

        try {

            $conectar->beginTransaction();

            $resultadoProducto = $conectar->prepare("SELECT precio, stock FROM productos WHERE id = ?");
            $resultadoProducto->execute([$producto_id]);
            $producto = $resultadoProducto->fetch(PDO::FETCH_ASSOC);

            if (!$producto || $producto['stock'] < $cantidad) {
                echo json_encode(["error" => !$producto ? "No existe este producto" : "Stock insuficiente"]);
                $conectar->rollBack();
                return;
            }

            $totalVenta = $producto['precio'] * $cantidad;

            $conectar->prepare("INSERT INTO ventas (producto_id, cantidad, total) VALUES (?, ?, ?)")
                    ->execute([$producto_id, $cantidad, $totalVenta]);

            $conectar->prepare("UPDATE productos SET stock = stock - ? WHERE id = ?")
                    ->execute([$cantidad, $producto_id]);

            $conectar->commit();

            echo json_encode(["mensaje"=>"Venta Registrada","total"=>$totalVenta]);

        } catch (Exception $ex) {
            $conectar->rollBack();
            echo json_encode(["error"=>"Error"]);
        }
    }


    }
?>