<?php

include_once "cruds.php";
header("Content-Type: application/json; charset=UTF-8");

$opcion = $_SERVER['REQUEST_METHOD'];

switch ($opcion) {
    case 'GET':
        $recurso = $_GET['recurso'] ?? 'productos';

        if ($recurso === 'ventas') {
            Cruds::ListaVentas();
        } else {
            Cruds::ListaProductos();
        }
        break;
    case 'POST':
        Cruds::RegistrarVenta();
        break;
}
?>